../adminer/plugin.php - demo usage
https://www.adminer.org/plugins/ - documentation
